import 'dart:convert';
import 'package:shared_preferences/shared_preferences.dart';
import '../models/note.dart';

class NoteService {
  static const String _notesKey = 'notes';
  final SharedPreferences _prefs;

  NoteService(this._prefs);

  Future<List<Note>> getNotes() async {
    final String? notesJson = _prefs.getString(_notesKey);
    if (notesJson == null) return [];

    final List<dynamic> notesList = json.decode(notesJson);
    return notesList.map((note) => Note.fromJson(note)).toList();
  }

  Future<void> addNote(Note note) async {
    final notes = await getNotes();
    notes.add(note);
    await _saveNotes(notes);
  }

  Future<void> updateNote(Note note) async {
    final notes = await getNotes();
    final index = notes.indexWhere((n) => n.id == note.id);
    if (index != -1) {
      notes[index] = note;
      await _saveNotes(notes);
    }
  }

  Future<void> deleteNote(String id) async {
    final notes = await getNotes();
    notes.removeWhere((note) => note.id == id);
    await _saveNotes(notes);
  }

  Future<void> _saveNotes(List<Note> notes) async {
    final String notesJson = json.encode(notes.map((note) => note.toJson()).toList());
    await _prefs.setString(_notesKey, notesJson);
  }

  Future<List<Note>> getReminders() async {
    final notes = await getNotes();
    return notes.where((note) => note.isReminder && note.reminderTime != null).toList();
  }
} 