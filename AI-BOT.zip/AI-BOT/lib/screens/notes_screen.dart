import 'package:flutter/material.dart';
import 'package:intl/intl.dart';
import '../models/note.dart';
import '../services/note_service.dart';
import 'package:shared_preferences/shared_preferences.dart';

class NotesScreen extends StatefulWidget {
  const NotesScreen({super.key});

  @override
  State<NotesScreen> createState() => _NotesScreenState();
}

class _NotesScreenState extends State<NotesScreen> {
  late NoteService _noteService;
  List<Note> _notes = [];
  bool _isLoading = true;

  @override
  void initState() {
    super.initState();
    _initializeNoteService();
  }

  Future<void> _initializeNoteService() async {
    final prefs = await SharedPreferences.getInstance();
    _noteService = NoteService(prefs);
    await _loadNotes();
  }

  Future<void> _loadNotes() async {
    setState(() => _isLoading = true);
    final notes = await _noteService.getNotes();
    setState(() {
      _notes = notes;
      _isLoading = false;
    });
  }

  Future<void> _addNote() async {
    final TextEditingController contentController = TextEditingController();
    DateTime? selectedDateTime;

    await showDialog(
      context: context,
      builder: (context) => AlertDialog(
        title: const Text('Add Note/Reminder'),
        content: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            TextField(
              controller: contentController,
              decoration: const InputDecoration(
                labelText: 'Note Content',
                hintText: 'Enter your note here',
              ),
              maxLines: 3,
            ),
            const SizedBox(height: 16),
            ElevatedButton(
              onPressed: () async {
                final DateTime? picked = await showDateTimePicker(context);
                if (picked != null) {
                  selectedDateTime = picked;
                }
              },
              child: const Text('Set Reminder (Optional)'),
            ),
          ],
        ),
        actions: [
          TextButton(
            onPressed: () => Navigator.pop(context),
            child: const Text('Cancel'),
          ),
          TextButton(
            onPressed: () async {
              if (contentController.text.isNotEmpty) {
                final note = Note(
                  id: DateTime.now().toString(),
                  content: contentController.text,
                  createdAt: DateTime.now(),
                  reminderTime: selectedDateTime,
                  isReminder: selectedDateTime != null,
                );
                await _noteService.addNote(note);
                await _loadNotes();
                Navigator.pop(context);
              }
            },
            child: const Text('Save'),
          ),
        ],
      ),
    );
  }

  Future<DateTime?> showDateTimePicker(BuildContext context) async {
    final DateTime? date = await showDatePicker(
      context: context,
      initialDate: DateTime.now(),
      firstDate: DateTime.now(),
      lastDate: DateTime.now().add(const Duration(days: 365)),
    );

    if (date != null) {
      final TimeOfDay? time = await showTimePicker(
        context: context,
        initialTime: TimeOfDay.now(),
      );

      if (time != null) {
        return DateTime(
          date.year,
          date.month,
          date.day,
          time.hour,
          time.minute,
        );
      }
    }
    return null;
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('Notes & Reminders'),
        actions: [
          IconButton(
            icon: const Icon(Icons.filter_list),
            onPressed: () {
              // TODO: Implement filtering
            },
          ),
        ],
      ),
      body: _isLoading
          ? const Center(child: CircularProgressIndicator())
          : _notes.isEmpty
              ? const Center(child: Text('No notes yet'))
              : ListView.builder(
                  itemCount: _notes.length,
                  itemBuilder: (context, index) {
                    final note = _notes[index];
                    return Dismissible(
                      key: Key(note.id),
                      onDismissed: (direction) async {
                        await _noteService.deleteNote(note.id);
                        await _loadNotes();
                      },
                      background: Container(
                        color: Colors.red,
                        alignment: Alignment.centerRight,
                        padding: const EdgeInsets.only(right: 16),
                        child: const Icon(Icons.delete, color: Colors.white),
                      ),
                      child: ListTile(
                        title: Text(note.content),
                        subtitle: Text(
                          DateFormat('MMM dd, yyyy - HH:mm').format(note.createdAt),
                        ),
                        trailing: note.isReminder
                            ? Icon(
                                Icons.alarm,
                                color: note.reminderTime!.isAfter(DateTime.now())
                                    ? Colors.blue
                                    : Colors.grey,
                              )
                            : null,
                        onTap: () {
                          // TODO: Implement note editing
                        },
                      ),
                    );
                  },
                ),
      floatingActionButton: FloatingActionButton(
        onPressed: _addNote,
        child: const Icon(Icons.add),
      ),
    );
  }
} 