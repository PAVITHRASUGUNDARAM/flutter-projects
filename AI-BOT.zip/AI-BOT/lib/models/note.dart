import 'dart:convert';

class Note {
  final String id;
  final String content;
  final DateTime createdAt;
  final DateTime? reminderTime;
  final bool isReminder;

  Note({
    required this.id,
    required this.content,
    required this.createdAt,
    this.reminderTime,
    this.isReminder = false,
  });

  Map<String, dynamic> toJson() {
    return {
      'id': id,
      'content': content,
      'createdAt': createdAt.toIso8601String(),
      'reminderTime': reminderTime?.toIso8601String(),
      'isReminder': isReminder,
    };
  }

  factory Note.fromJson(Map<String, dynamic> json) {
    return Note(
      id: json['id'],
      content: json['content'],
      createdAt: DateTime.parse(json['createdAt']),
      reminderTime: json['reminderTime'] != null
          ? DateTime.parse(json['reminderTime'])
          : null,
      isReminder: json['isReminder'] ?? false,
    );
  }

  Note copyWith({
    String? id,
    String? content,
    DateTime? createdAt,
    DateTime? reminderTime,
    bool? isReminder,
  }) {
    return Note(
      id: id ?? this.id,
      content: content ?? this.content,
      createdAt: createdAt ?? this.createdAt,
      reminderTime: reminderTime ?? this.reminderTime,
      isReminder: isReminder ?? this.isReminder,
    );
  }
} 