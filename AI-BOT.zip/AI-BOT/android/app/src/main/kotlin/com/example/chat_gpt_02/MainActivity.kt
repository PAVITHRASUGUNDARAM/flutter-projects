package com.example.chat_gpt_02

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
